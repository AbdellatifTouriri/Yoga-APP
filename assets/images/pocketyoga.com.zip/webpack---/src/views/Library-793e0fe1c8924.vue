








































import Vue from 'vue';
import { Route } from 'vue-router';
import Search from '@/components/Search.vue';
import Sort from '@/components/Sort.vue';
import store from '@/data/store';

const removeDiacritics = require('diacritics').remove;

interface Store {
  clean: boolean;
  search: string | null;
  sort: string;
  [key: string]: string | number | boolean | null;
}

/* eslint-disable */

// eslint disabled to allow underscored interface properties
// since these come from an API we cannot camel case

interface SanskritNames {
  latin: string;
  devanagari: string;
  simplified: string;
}

interface LibraryPose {
  aka: string[];
  base_name: string;
  category: string;
  difficulty: string;
  display_name: string;
  name: string;
  preferred_side: string | null;
  sanskrit_names: SanskritNames[];
  sideways: boolean;
  sort_name: string;
  subcategory: string | null;
  two_sided: boolean;
  visibility: string;
}

/* eslint-enable */
interface LibraryDisplay {
  title: string;
  titleVisible: boolean;
  poses: LibraryPose[];
}

interface LibraryData {
  lastFetch: string | null;
  loading: boolean;
  posesForDisplay: LibraryDisplay[];
  search: string | null;
  sort: string;
  store: Store;
  [key: string]: string | number | boolean | LibraryDisplay[] | Store | null;
}

export default Vue.extend({
  name: 'library',
  components: {
    Search,
    Sort,
  },
  data() {
    return {
      lastFetch: null,
      loading: false,
      posesForDisplay: [],
      sort: 'category',
      search: null,
      store,
    } as LibraryData;
  },
  created() {
    // Recall last library state if we used back/foward to get here
    if (!this.store.clean) {
      this.loadState();
      this.updateUrl();
    }
  },
  mounted() {
    this.assignParamData();
    this.fetchData();
    this.setMeta();
  },
  watch: {
    $route: 'routeChanged',
  },
  methods: {
    assignParamData() {
      const props: string[] = ['sort', 'search'];
      const used: string[] = Object.keys(this.$route.query);

      props.forEach((prop) => {
        if (used.includes(prop)) {
          const value = this.$route.query[prop].toString();

          this[prop] = value;
          this.store[prop] = value;
        } else if (prop === 'sort') {
          this[prop] = 'category';
          this.store[prop] = 'category';
        } else {
          // Default to null for other properties
          this[prop] = null;
          this.store[prop] = null;
        }
      });

      this.store.clean = false;
    },
    changeSort(sort: string) {
      this.sort = sort;
      this.updateUrl();
    },
    changeTerm(term: string) {
      this.search = term;
      this.updateUrl();
    },
    fetchData() {
      const props: string[] = ['sort', 'search'];
      let query: string = '';

      props.forEach((prop) => {
        if (this[prop] !== null && this[prop] !== '') {
          let propValue = this[prop];

          if (prop === 'search' && propValue !== null) {
            propValue = removeDiacritics(propValue.toString().trim());
          }

          if (propValue !== null && propValue !== '') {
            propValue = propValue as string | number;

            query += `${(query === '' ? '?' : '&')}${prop}=${encodeURIComponent(propValue)}`;
          }
        }
      });

      if (this.lastFetch !== query) {
        this.loading = true;
        this.lastFetch = query;

        // Reassign this scope for callback usage
        const component = this;

        fetch('/poses.json')
          .then((response) => {
            if (!response.ok) {
              throw response;
            }

            return response.json();
          })
          .then((json) => {
            // JSON list to work from
            let poses: LibraryPose[] = json;

            // Structure for front end use
            const posesForDisplay: LibraryDisplay[] = [];

            if (!component.search) {
              poses = poses.filter(pose => pose.visibility === 'primary');
            } else {
              poses = poses
                .filter(pose => ['primary', 'secondary'].includes(pose.visibility))
                .filter((pose) => {
                  const searchNormalized = component.search!.toLowerCase();

                  // Search takes place on each term independently
                  const searchTerms = searchNormalized.split(' ');
                  let matchCount = 0;

                  for (let i = 0; i < searchTerms.length; i += 1) {
                    const regex = new RegExp(`\\b${searchTerms[i]}+`, 'gi');

                    if (pose.display_name.toLowerCase().match(regex)) {
                      matchCount++;
                      continue;
                    }

                    if (pose.aka) {
                      const match = pose.aka.find(aka => aka.toLowerCase()
                        .match(regex));

                      if (match) {
                        matchCount++;
                        continue;
                      }
                    }

                    if (pose.sanskrit_names) {
                      const match = pose.sanskrit_names
                        .find(sanskrit => removeDiacritics(sanskrit.latin)
                          .toLowerCase().match(regex)
                          || sanskrit.simplified.toLowerCase().match(regex));

                      if (match) {
                        matchCount++;
                        continue;
                      }
                    }
                  }

                  if (matchCount === searchTerms.length) {
                    return true;
                  }

                  return false;
                });
            }

            // Sort poses by sort name
            poses = poses
              .sort((a, b) => {
                const textA = a.sort_name.toUpperCase();
                const textB = b.sort_name.toUpperCase();
                if (textA < textB) return -1;
                if (textA > textB) return 1;
                return 0;
              })
              .map(pose => ({
                ...pose,
                base_name: pose.name.replace(/\s+/g, ''),
              }));

            if (component.sort === 'category') {
              const categories = [
                { filter: 'standing', title: 'Standing' },
                { filter: 'seated', title: 'Seated' },
                { filter: 'supine', title: 'Supine' },
                { filter: 'prone', title: 'Prone' },
                { filter: 'arm_leg_support', title: 'Arm & Leg Support' },
                { filter: 'arm_balance_and_inversion', title: 'Arm Balance & Inversion' },
              ];

              categories.forEach((category) => {
                const matches = poses.filter(pose => pose.category === category.filter);

                if (matches.length > 0) {
                  posesForDisplay.push({
                    title: category.title,
                    titleVisible: true,
                    poses: matches,
                  });
                }
              });
            }

            if (component.sort === 'subcategory') {
              const subcategories = [
                { filter: 'backbend', title: 'Backbend' },
                { filter: 'forward_bend', title: 'Forward Bend' },
                { filter: 'lateral_bend', title: 'Lateral Bend' },
                { filter: 'twist', title: 'Twist' },
                { filter: 'balancing', title: 'Balancing' },
                { filter: 'neutral', title: 'Neutral' },
              ];

              subcategories.forEach((subcategory) => {
                const matches = poses.filter(pose => pose.subcategory === subcategory.filter);

                if (matches.length > 0) {
                  posesForDisplay.push({
                    title: subcategory.title,
                    titleVisible: true,
                    poses: matches,
                  });
                }
              });
            }

            if (component.sort === 'difficulty') {
              const difficulties = [
                { filter: 'beginner', title: 'Beginner' },
                { filter: 'intermediate', title: 'Intermediate' },
                { filter: 'expert', title: 'Advanced' },
              ];

              difficulties.forEach((difficulty) => {
                const matches = poses.filter(pose => pose.difficulty === difficulty.filter);

                if (matches.length > 0) {
                  posesForDisplay.push({
                    title: difficulty.title,
                    titleVisible: true,
                    poses: matches,
                  });
                }
              });
            }

            if (component.sort === 'alphabetical' && poses.length) {
              posesForDisplay.push({
                title: 'Alphabetical',
                titleVisible: false,
                poses,
              });
            }

            component.posesForDisplay = posesForDisplay;
            component.loading = false;
          })
          .catch((err) => {
            component.loading = false;
          });
      }
    },
    loadState() {
      this.search = this.store.search;
      this.sort = this.store.sort;
    },
    routeChanged(to: Route, from: Route) {
      this.assignParamData();
      this.fetchData();
      this.setMeta();
    },
    setMeta() {
      document.title = 'Yoga Poses Dictionary | Pocket Yoga';

      const metaDescription: HTMLElement | null = document.querySelector('meta[name="description"]');
      const metaKeywords: HTMLElement | null = document.querySelector('meta[name="keywords"]');

      if (metaDescription !== null) {
        metaDescription.setAttribute('content', 'A searchable dictionary of yoga poses. Find a new yoga pose or learn about one of your favorites with images, descriptions, and benefits for each pose.');
      }

      if (metaKeywords !== null) {
        metaKeywords.setAttribute('content', 'yoga poses, search, categories, difficulty');
      }
    },
    updateUrl() {
      const query = {} as any;

      if (this.sort) {
        query.sort = this.sort;
      }

      if (this.search !== null && this.search.trimLeft() !== '') {
        query.search = this.search.trimLeft();
      }

      this.$router.push({ query });
    },
  },
  filters: {
    alphanumeric(value: string) {
      if (!value) {
        return '';
      }

      return value.replace(/\W/g, '');
    },
    commaSpace(value: string) {
      if (!value) {
        return '';
      }

      const pieces = value.split(',');

      switch (pieces.length) {
        case 2:
          return `${pieces[0]}, ${pieces[1]}`;
        case 3:
          return pieces[1].length === 0 ? `${pieces[0]} (${pieces[2]})` : `${pieces[0]}, ${pieces[1]} (${pieces[2]})`;
        default:
          return value;
      }
    },
    formatSanskrit(value: SanskritNames[]) {
      if (!value) {
        return '';
      }

      return value[0].simplified;
    },
    thumbImg(value: LibraryPose) {
      if (!value) {
        return '';
      }

      let src = `https://pocketyoga.com/assets/images/thumbnails146/${value.base_name}`;

      if (value.preferred_side !== null && (value.two_sided || value.sideways)) {
        src += `_${value.preferred_side.charAt(0).toUpperCase()}`;
      }

      return `${src}-tn146.png`;
    },
  },
});
