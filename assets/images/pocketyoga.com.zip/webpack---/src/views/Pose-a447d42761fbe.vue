































































































































































import Vue from 'vue';
import { Route } from 'vue-router';
import poses from '@/data/poses';

const removeDiacritics = require('diacritics').remove;

/* eslint-disable */

// eslint disabled to allow underscored interface properties
// since these come from an API we cannot camel case

interface SanskritNames {
  latin: string;
  devanagari: string;
  simplified: string;
  translation: {
    latin: string;
    devanagari: string;
    simplified: string;
    description: string;
  }[]
}

interface RelatedPose {
  base_name: string;
  preferred_side: string | null;
  two_sided: boolean;
  sideways: boolean;
  name: string;
  display_name: string;
}

interface LibraryPose {
  aka: string[];
  alt: string,
  base_name: string;
  category: string;
  difficulty: string;
  display_name: string;
  name: string;
  next_poses: string[];
  next_pose_objs: RelatedPose[];
  preferred_side: string | null;
  previous_poses: string[],
  previous_pose_objs: RelatedPose[];
  sanskrit_interpretation: string | null;
  sanskrit_names: SanskritNames[];
  sideways: boolean;
  sort_name: string;
  subcategory: string | null;
  two_sided: boolean;
  variations: string[]
  variation_objs: RelatedPose[];
  visibility: string;
  [key: string]: boolean | string | string[] | RelatedPose[] | SanskritNames[] | null;
}

/* eslint-enable */

interface Poses {
  [key: string]: LibraryPose
}

interface PoseData {
  conserveHeight: string | number,
  initialLeft: string;
  initialLoad: boolean;
  loading: boolean;
  notFound: boolean;
  pose: LibraryPose | null;
  posesData: LibraryPose[];
  poses: Poses,
  rotate: boolean;
  [key: string]: string | number | boolean | LibraryPose | LibraryPose[] | Poses | null;
}

export default Vue.extend({
  name: 'pose',
  data() {
    return {
      conserveHeight: 'auto',
      initialLeft: '0px',
      initialLoad: false,
      loading: true,
      notFound: false,
      open: null,
      pose: null,
      posesData: [],
      poses,
      rotate: false,
    } as PoseData;
  },
  mounted() {
    this.fetchData();
  },
  watch: {
    $route: 'routeChanged',
  },
  methods: {
    changePose(event: MouseEvent) {
      event.preventDefault();

      const target = event.target as HTMLElement;

      if (target.localName === 'a') {
        this.$router.push(`${target.getAttribute('href')}`);
      }
    },
    changeSide() {
      this.rotate = !this.rotate;
    },
    fetchData() {
      if (document.getElementsByClassName('mainProduct').length) {
        this.conserveHeight = `${document.getElementsByClassName('mainProduct')[0].clientHeight}px`;
      }

      this.loading = true;
      this.notFound = false;

      const lookup = this.$route.params.pose;
      const formatted = this.$route.params.pose.replace(/(?:^|_)(\w)/g, function(_, letter) {
        return letter.toUpperCase();
      }).replace(/_/g, '');

      if (lookup !== formatted) {
        window.location.href = formatted;
        return;
      }

      const component = this;

      fetch('/poses.json')
        .then((response) => {
          if (!response.ok) {
            throw response;
          }

          return response.json();
        })
        .then((json: LibraryPose[]) => {
          const pose = json.find(match => lookup === match.name.replace(/\s+/g, ''));

          if (!pose) {
            throw new Error('Not found');
          }

          pose.base_name = pose.name.replace(/\s+/g, '');
          const relations = [
            { source: 'next_poses', result: 'next_pose_objs' },
            { source: 'previous_poses', result: 'previous_pose_objs' },
            { source: 'variations', result: 'variation_objs' },
          ];

          if (pose.variations) {
            pose.variations.unshift(pose.name);
          } else {
            // Check if pose is a variation of another pose
            const parent = json
              .find(match => match.variations && match.variations.includes(pose.name));

            if (parent) {
              pose.variations = parent.variations;
              pose.variations.unshift(parent.name);
            } else {
              pose.variations = [pose.name];
            }
          }

          relations.forEach((relation) => {
            pose[relation.result] = [];

            if (pose[relation.source]) {
              pose[relation.source] = (pose[relation.source] as string[]).map(rel => rel.replace(/\s+/g, ''));
              pose[relation.result] = (pose[relation.source] as string[])
                .map(relation => json.find(match => match.name.replace(/\s+/g, '') == relation))
                .filter(match => match !== undefined)
                .map(match => ({
                  name: match!.name,
                  base_name: match!.name.replace(/\s+/g, ''),
                  display_name: match!.display_name,
                  preferred_side: match!.preferred_side,
                  sideways: match!.sideways,
                  two_sided: match!.two_sided,
                }));

              /* pose[relation.result] = json
                  .filter(match => (pose[relation.source] as string[]).includes(match.name.replace(/\s+/g, '')))
                  .map(match => ({
                    name: match.name,
                    base_name: match.name.replace(/\s+/g, ''),
                    display_name: match.display_name,
                    preferred_side: match.preferred_side,
                    sideways: match.sideways,
                    two_sided: match.two_sided,
                  })); */
            }
          });

          component.posesData = json;

          return pose;
        })
        .then((json: LibraryPose) => {
          const pose = json;

          if (pose.sanskrit_interpretation) {
            pose.sanskrit_interpretation = pose.sanskrit_interpretation.replace(/\/\//g, '\\n\\n');
            const items = pose.sanskrit_interpretation.split(/\\n/);
            pose.sanskrit_interpretation = `<li><div class="trans">${items.join('</div></li><li><div class="trans">')}</div></li>`;
          }

          pose.alt = `Yoga Pose: ${pose.display_name}`;

          if (pose.difficulty === 'expert') {
            pose.difficulty = 'advanced';
          }

          const matches = pose.alt.match(/\bI{1,3}\b|\bIV\b|\bV\b/g);

          if (matches) {
            for (let i = 0; i < matches.length; i += 1) {
              let num = ' 1';
              let txt = ' One';

              switch (matches[i]) {
                case 'I':
                  num = ' 1';
                  txt = ' One';
                  break;
                case 'II':
                  num = ' 2';
                  txt = ' Two';
                  break;
                case 'III':
                  num = ' 3';
                  txt = ' Three';
                  break;
                case 'IV':
                  num = ' 4';
                  txt = ' Four';
                  break;
                case 'V':
                  num = ' 5';
                  txt = ' Five';
                  break;
                default:
                  num = ' 1';
                  txt = ' One';
              }

              pose.alt += `, ${pose.display_name.replace(` ${matches[i]}`, num)}, ${pose.display_name.replace(` ${matches[i]}`, txt)}`;

              break;
            }
          }

          if (pose.aka) {
            pose.alt += `, ${pose.aka.join(', ')}`;
            pose.alt = pose.alt.trim();
          }

          if (pose.sanskrit_names) {
            pose.alt += `, ${pose.sanskrit_names
              .map(val => `${val.latin}, ${val.simplified}`)
              .join(', ')}`;
          }

          if (!component.initialLoad) {
            component.initialLeft = '0px';

            if (pose.variation_objs.length > 9) {
              for (let i = 0; i < pose.variation_objs.length; i += 1) {
                if (pose.variation_objs[i].base_name === pose.base_name) {
                  if (i > 8) {
                    component.initialLeft = `-${(pose!.variations.length - 9) * 100}px`;
                  }
                  break;
                }
              }
            }
          }

          component.pose = pose;
          // component.poses[lookup] = pose;
          component.setMeta();
          component.rotate = false;

          setTimeout(() => {
            component.initialLoad = true;
            component.loading = false;
            component.conserveHeight = 'auto';

            setTimeout(() => {
              if (component.pose!.variation_objs!.findIndex(elem => elem.base_name === component.pose!.base_name!) > 8) {
                  document.getElementById('vars')!.style.left = `-${(component.pose!.variation_objs!.length - 9) * 100}px`;
                  component.initialLeft = `-${(component.pose!.variation_objs!.length - 9) * 100}px`;
              } else {
                  document.getElementById('vars')!.style.left = '0px';
                  component.initialLeft = '0px';
              }
            });
          });
        })
        .catch(() => {
          component.notFound = true;
          component.rotate = false;

          setTimeout(() => {
            component.loading = false;
            component.conserveHeight = 'auto';
          });
        });
    },
    nl2br(value: string) {
      if (!value) {
        return '';
      }

      // Convert line returns to br tags and sanskrit splits to commas
      return value
        .replace(/\\n/g, '<br/>')
        .replace(/\\"/g, '"')
        .replace(/\/\/(.+?)\/\//g, (_, link) => `<a href="${link.replace(/\s+/g, '')}">${this.posesData.find(match => match.name === link)!.display_name}</a>`);
    },
    openTranslation(event: MouseEvent) {
      event.preventDefault();

      if (event && event.target) {
        this.open = parseInt((event.target as HTMLLinkElement).getAttribute('data-index') || '0', 10);
      }
    },
    routeChanged() {
      this.fetchData();
    },
    setMeta() {
      if (this.pose !== null) {
        document.title = `Yoga Pose: ${this.pose.display_name} | Pocket Yoga`;

        const metaDescription: HTMLElement | null = document.querySelector('meta[name="description"]');
        const metaKeywords: HTMLElement | null = document.querySelector('meta[name="keywords"]');

        if (metaDescription !== null) {
          metaDescription.setAttribute('content', `A detailed description and benefits of the ${this.pose.display_name} pose including image, sanskrit name, category, difficulty, and a list of variations, previous, and next poses.`);
        }

        if (metaKeywords !== null && this.pose !== null) {
          let keywords = `yoga pose, ${this.pose.display_name}`;

          if (this.pose.aka) {
            keywords += `, ${this.pose.aka.join(', ')}`;
          }

          if (this.pose.sanskrit_name) {
            keywords += `, ${this.pose.sanskrit_name}`;
          }

          metaKeywords.setAttribute('content', keywords);
        }
      }
    },
    shiftLeft(event: MouseEvent) {
      event.preventDefault();
      document.getElementById('vars')!.style.left = '0px';
      this.initialLeft = '0px';
    },
    shiftRight(event: MouseEvent) {
      event.preventDefault();
      document.getElementById('vars')!.style.left = `-${(this.pose!.variations.length - 9) * 100}px`;
      this.initialLeft = `-${(this.pose!.variations.length - 9) * 100}px`;
    },
  },
  filters: {
    capitalize(value: string) {
      if (!value) {
        return '';
      }

      return `${value.toString().charAt(0).toUpperCase()}${value.toString().slice(1)}`;
    },
    formatCategory(value: string) {
      if (!value) {
        return '';
      }

      const categories: string[] = value.replace(/_/g, ' ').split(' ');

      for (let i = 0; i < categories.length; i += 1) {
        categories[i] = `${categories[i].charAt(0).toUpperCase()}${categories[i].slice(1)}`;
      }

      return categories.join(' ');
    },
    mainImg(value: LibraryPose, rotate: boolean) {
      if (!value) {
        return '';
      }

      let src = `https://pocketyoga.com/assets/images/full/${value.base_name}`;

      if (value.preferred_side !== null && (value.two_sided || value.sideways)) {
        if (rotate && value.preferred_side === 'left') {
          src += '_R';
        } else if (rotate && value.preferred_side === 'right') {
          src += '_L';
        } else {
          src += `_${value.preferred_side.charAt(0).toUpperCase()}`;
        }
      }

      return `${src}.png`;
    },
    relatedMedImg(value: LibraryPose) {
      if (!value) {
        return '';
      }

      let src = `https://pocketyoga.com/assets/images/thumbnails90/${value.base_name}`;

      if (value.preferred_side !== null && (value.two_sided || value.sideways)) {
        src += `_${value.preferred_side.charAt(0).toUpperCase()}`;
      }

      return `${src}-tn90.png`;
    },
    relatedImg(value: LibraryPose) {
      if (!value) {
        return '';
      }

      let src = `https://pocketyoga.com/assets/images/thumbnails75/${value.base_name}`;

      if (value.preferred_side !== null && (value.two_sided || value.sideways)) {
        src += `_${value.preferred_side.charAt(0).toUpperCase()}`;
      }

      return `${src}-tn75.png`;
    },
  },
});
