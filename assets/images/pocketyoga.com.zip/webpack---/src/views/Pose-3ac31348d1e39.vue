import { render, staticRenderFns } from "./Pose.vue?vue&type=template&id=6bc1d094&"
import script from "./Pose.vue?vue&type=script&lang=ts&"
export * from "./Pose.vue?vue&type=script&lang=ts&"
import style0 from "./Pose.vue?vue&type=style&index=0&lang=css&"


/* normalize component */
import normalizer from "!../../node_modules/vue-loader/lib/runtime/componentNormalizer.js"
var component = normalizer(
  script,
  render,
  staticRenderFns,
  false,
  null,
  null,
  null
  
)

export default component.exports