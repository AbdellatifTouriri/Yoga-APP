export default {
  clean: true as boolean,
  search: null as string | null,
  sort: null as string | null,
};
