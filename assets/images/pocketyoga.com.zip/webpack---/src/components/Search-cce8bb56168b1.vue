var render = function () {var _vm=this;var _h=_vm.$createElement;var _c=_vm._self._c||_h;return _c('div',{staticClass:"search-bar"},[_c('input',{directives:[{name:"model",rawName:"v-model",value:(_vm.localTerm),expression:"localTerm"}],attrs:{"type":"text","id":"search","name":"search","placeholder":"search"},domProps:{"value":(_vm.localTerm)},on:{"input":function($event){if($event.target.composing){ return; }_vm.localTerm=$event.target.value}}}),_c('input',{attrs:{"type":"button","id":"searchButton","value":""}})])}
var staticRenderFns = []

export { render, staticRenderFns }