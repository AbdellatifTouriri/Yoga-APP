













import Vue from 'vue';

export default Vue.extend({
  name: 'Search',
  props: {
    term: String,
  },
  data() {
    return {
      debounce: undefined as number | undefined,
      localTerm: '' as string | null,
    };
  },
  mounted() {
    this.localTerm = this.term;
  },
  watch: {
    $route() {
      const used = Object.keys(this.$route.query);
      if (used.includes('search')) {
        this.localTerm = this.$route.query.search as string;
      } else {
        this.localTerm = null;
      }
    },
    localTerm(value) {
      if (this.localTerm !== this.term) {
        clearTimeout(this.debounce);
        this.debounce = window.setTimeout(() => {
          this.$emit('changeTerm', value);
        }, 275);
      }
    },
  },
});
