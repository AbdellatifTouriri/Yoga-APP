





































import Vue from 'vue';

export default Vue.extend({
  name: 'Sort',
  data() {
    return {
      open: false,
    };
  },
  props: {
    sort: String,
  },
  methods: {
    onChangeSort(changeSort: string) {
      this.open = false;
      this.$emit('changeSort', changeSort);
    },
  },
});
