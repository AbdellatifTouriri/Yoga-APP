(function(t) {
    function e(e) {
        for (var a, r, o = e[0], c = e[1], l = e[2], p = 0, f = []; p < o.length; p++) r = o[p], Object.prototype.hasOwnProperty.call(s, r) && s[r] && f.push(s[r][0]), s[r] = 0;
        for (a in c) Object.prototype.hasOwnProperty.call(c, a) && (t[a] = c[a]);
        u && u(e);
        while (f.length) f.shift()();
        return i.push.apply(i, l || []), n()
    }

    function n() {
        for (var t, e = 0; e < i.length; e++) {
            for (var n = i[e], a = !0, o = 1; o < n.length; o++) {
                var c = n[o];
                0 !== s[c] && (a = !1)
            }
            a && (i.splice(e--, 1), t = r(r.s = n[0]))
        }
        return t
    }
    var a = {},
        s = {
            app: 0
        },
        i = [];

    function r(e) {
        if (a[e]) return a[e].exports;
        var n = a[e] = {
            i: e,
            l: !1,
            exports: {}
        };
        return t[e].call(n.exports, n, n.exports, r), n.l = !0, n.exports
    }
    r.m = t, r.c = a, r.d = function(t, e, n) {
        r.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: n
        })
    }, r.r = function(t) {
        "undefined" !== typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, r.t = function(t, e) {
        if (1 & e && (t = r(t)), 8 & e) return t;
        if (4 & e && "object" === typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
        if (r.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var a in t) r.d(n, a, function(e) {
                return t[e]
            }.bind(null, a));
        return n
    }, r.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t["default"]
        } : function() {
            return t
        };
        return r.d(e, "a", e), e
    }, r.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, r.p = "/pose/";
    var o = window["webpackJsonp"] = window["webpackJsonp"] || [],
        c = o.push.bind(o);
    o.push = e, o = o.slice();
    for (var l = 0; l < o.length; l++) e(o[l]);
    var u = c;
    i.push([0, "chunk-vendors"]), n()
})({
    0: function(t, e, n) {
        t.exports = n("cd49")
    },
    "0782": function(t, e, n) {
        "use strict";
        n("c3668")
    },
    "69c3": function(t, e, n) {},
    7997: function(t, e, n) {},
    "883d": function(t, e, n) {
        "use strict";
        n("69c3")
    },
    ba2e: function(t, e, n) {},
    baf9: function(t, e, n) {
        "use strict";
        n("ba2e")
    },
    c3668: function(t, e, n) {},
    cd49: function(t, e, n) {
        "use strict";
        n.r(e);
        n("cadf"), n("551c"), n("f751"), n("097d");
        var a = n("2b0e"),
            s = function() {
                var t = this,
                    e = t.$createElement,
                    n = t._self._c || e;
                return n("section", {
                    staticClass: "mainContent"
                }, [n("router-view")], 1)
            },
            i = [],
            r = n("2877"),
            o = {},
            c = Object(r["a"])(o, s, i, !1, null, null, null),
            l = c.exports,
            u = n("8c4f"),
            p = function() {
                var t = this,
                    e = t.$createElement,
                    n = t._self._c || e;
                return n("section", {
                    staticClass: "poseDictionary"
                }, [n("nav", {
                    staticClass: "posesNav"
                }, [null !== t.lastFetch ? n("Search", {
                    attrs: {
                        term: t.search
                    },
                    on: {
                        changeTerm: t.changeTerm
                    }
                }) : t._e(), n("Sort", {
                    attrs: {
                        sort: t.sort
                    },
                    on: {
                        changeSort: t.changeSort
                    }
                })], 1), n("section", {
                    staticClass: "posesDisplay"
                }, [t._l(t.posesForDisplay, (function(e, a) {
                    return [e.poses.length && e.titleVisible ? n("h3", {
                        key: e.title
                    }, [t._v(t._s(e.title))]) : t._e(), e.poses.length ? n("ul", {
                        key: a
                    }, t._l(e.poses, (function(e, a) {
                        return n("li", {
                            key: a
                        }, [n("router-link", {
                            attrs: {
                                to: e.base_name,
                                title: t._f("commaSpace")(e.display_name)
                            }
                        }, [n("img", {
                            attrs: {
                                src: t._f("thumbImg")(e),
                                alt: ""
                            }
                        }), n("div", {
                            staticClass: "pose-title"
                        }, [n("h6", {
                            staticClass: "big"
                        }, [t._v(t._s(t._f("commaSpace")(e.display_name)))]), n("h6", {
                            staticClass: "smaller"
                        }, [t._v(t._s(t._f("formatSanskrit")(e.sanskrit_names)))])])])], 1)
                    })), 0) : t._e()]
                })), t.loading || t.posesForDisplay.length ? t._e() : n("p", [t._v("\n      No poses found. Please try another search.\n    ")])], 2)])
            },
            f = [],
            d = (n("8e6e"), n("7f7f"), n("a481"), n("bd86")),
            h = (n("55dd"), n("7514"), n("4917"), n("3b2b"), n("28a5"), n("386d"), n("6b54"), n("6762"), n("2fdb"), n("ac6a"), n("456d"), function() {
                var t = this,
                    e = t.$createElement,
                    n = t._self._c || e;
                return n("div", {
                    staticClass: "search-bar"
                }, [n("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: t.localTerm,
                        expression: "localTerm"
                    }],
                    attrs: {
                        type: "text",
                        id: "search",
                        name: "search",
                        placeholder: "search"
                    },
                    domProps: {
                        value: t.localTerm
                    },
                    on: {
                        input: function(e) {
                            e.target.composing || (t.localTerm = e.target.value)
                        }
                    }
                }), n("input", {
                    attrs: {
                        type: "button",
                        id: "searchButton",
                        value: ""
                    }
                })])
            }),
            m = [],
            g = a["a"].extend({
                name: "Search",
                props: {
                    term: String
                },
                data: function() {
                    return {
                        debounce: void 0,
                        localTerm: ""
                    }
                },
                mounted: function() {
                    this.localTerm = this.term
                },
                watch: {
                    $route: function() {
                        var t = Object.keys(this.$route.query);
                        t.includes("search") ? this.localTerm = this.$route.query.search : this.localTerm = null
                    },
                    localTerm: function(t) {
                        var e = this;
                        this.localTerm !== this.term && (clearTimeout(this.debounce), this.debounce = window.setTimeout((function() {
                            e.$emit("changeTerm", t)
                        }), 275))
                    }
                }
            }),
            _ = g,
            v = (n("0782"), Object(r["a"])(_, h, m, !1, null, null, null)),
            b = v.exports,
            y = function() {
                var t = this,
                    e = t.$createElement,
                    n = t._self._c || e;
                return n("div", {
                    staticClass: "poseSort"
                }, [n("div", {
                    staticClass: "overlay",
                    class: {
                        enabled: t.open
                    },
                    on: {
                        click: function(e) {
                            t.open = !t.open
                        }
                    }
                }), n("button", {
                    on: {
                        click: function(e) {
                            t.open = !t.open
                        }
                    }
                }, [t._v("Sort By")]), t.open ? n("ul", [n("li", [n("button", {
                    class: {
                        selected: "alphabetical" === t.sort
                    },
                    on: {
                        click: function(e) {
                            return t.onChangeSort("alphabetical")
                        }
                    }
                }, [t._v("Name")])]), n("li", [n("button", {
                    class: {
                        selected: "category" === t.sort
                    },
                    on: {
                        click: function(e) {
                            return t.onChangeSort("category")
                        }
                    }
                }, [t._v("Category")])]), n("li", [n("button", {
                    class: {
                        selected: "subcategory" === t.sort
                    },
                    on: {
                        click: function(e) {
                            return t.onChangeSort("subcategory")
                        }
                    }
                }, [t._v("Sub-Category")])]), n("li", [n("button", {
                    class: {
                        selected: "difficulty" === t.sort
                    },
                    on: {
                        click: function(e) {
                            return t.onChangeSort("difficulty")
                        }
                    }
                }, [t._v("Difficulty")])])]) : t._e()])
            },
            k = [],
            C = a["a"].extend({
                name: "Sort",
                data: function() {
                    return {
                        open: !1
                    }
                },
                props: {
                    sort: String
                },
                methods: {
                    onChangeSort: function(t) {
                        this.open = !1, this.$emit("changeSort", t)
                    }
                }
            }),
            w = C,
            j = (n("fc42"), Object(r["a"])(w, y, k, !1, null, null, null)),
            S = j.exports,
            x = {
                clean: !0,
                search: null,
                sort: null
            };

        function P(t, e) {
            var n = Object.keys(t);
            if (Object.getOwnPropertySymbols) {
                var a = Object.getOwnPropertySymbols(t);
                e && (a = a.filter((function(e) {
                    return Object.getOwnPropertyDescriptor(t, e).enumerable
                }))), n.push.apply(n, a)
            }
            return n
        }

        function O(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = null != arguments[e] ? arguments[e] : {};
                e % 2 ? P(Object(n), !0).forEach((function(e) {
                    Object(d["a"])(t, e, n[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(n)) : P(Object(n)).forEach((function(e) {
                    Object.defineProperty(t, e, Object.getOwnPropertyDescriptor(n, e))
                }))
            }
            return t
        }
        var I = n("0bdc").remove,
            T = a["a"].extend({
                name: "library",
                components: {
                    Search: b,
                    Sort: S
                },
                data: function() {
                    return {
                        lastFetch: null,
                        loading: !1,
                        posesForDisplay: [],
                        sort: "category",
                        search: null,
                        store: x
                    }
                },
                created: function() {
                    this.store.clean || (this.loadState(), this.updateUrl())
                },
                mounted: function() {
                    this.assignParamData(), this.fetchData(), this.setMeta()
                },
                watch: {
                    $route: "routeChanged"
                },
                methods: {
                    assignParamData: function() {
                        var t = this,
                            e = ["sort", "search"],
                            n = Object.keys(this.$route.query);
                        e.forEach((function(e) {
                            if (n.includes(e)) {
                                var a = t.$route.query[e].toString();
                                t[e] = a, t.store[e] = a
                            } else "sort" === e ? (t[e] = "category", t.store[e] = "category") : (t[e] = null, t.store[e] = null)
                        })), this.store.clean = !1
                    },
                    changeSort: function(t) {
                        this.sort = t, this.updateUrl()
                    },
                    changeTerm: function(t) {
                        this.search = t, this.updateUrl()
                    },
                    fetchData: function() {
                        var t = this,
                            e = ["sort", "search"],
                            n = "";
                        if (e.forEach((function(e) {
                                if (null !== t[e] && "" !== t[e]) {
                                    var a = t[e];
                                    "search" === e && null !== a && (a = I(a.toString().trim())), null !== a && "" !== a && (a = a, n += "".concat("" === n ? "?" : "&").concat(e, "=").concat(encodeURIComponent(a)))
                                }
                            })), this.lastFetch !== n) {
                            this.loading = !0, this.lastFetch = n;
                            var a = this;
                            fetch("/poses.json").then((function(t) {
                                if (!t.ok) throw t;
                                return t.json()
                            })).then((function(t) {
                                var e = t,
                                    n = [];
                                if (e = a.search ? e.filter((function(t) {
                                        return ["primary", "secondary"].includes(t.visibility)
                                    })).filter((function(t) {
                                        for (var e = a.search.toLowerCase(), n = e.split(" "), s = 0, i = function(e) {
                                                var a = new RegExp("\\b".concat(n[e], "+"), "gi");
                                                if (t.display_name.toLowerCase().match(a)) return s++, "continue";
                                                if (t.aka) {
                                                    var i = t.aka.find((function(t) {
                                                        return t.toLowerCase().match(a)
                                                    }));
                                                    if (i) return s++, "continue"
                                                }
                                                if (t.sanskrit_names) {
                                                    var r = t.sanskrit_names.find((function(t) {
                                                        return I(t.latin).toLowerCase().match(a) || t.simplified.toLowerCase().match(a)
                                                    }));
                                                    if (r) return s++, "continue"
                                                }
                                            }, r = 0; r < n.length; r += 1) i(r);
                                        return s === n.length
                                    })) : e.filter((function(t) {
                                        return "primary" === t.visibility
                                    })), e = e.sort((function(t, e) {
                                        var n = t.sort_name.toUpperCase(),
                                            a = e.sort_name.toUpperCase();
                                        return n < a ? -1 : n > a ? 1 : 0
                                    })).map((function(t) {
                                        return O(O({}, t), {}, {
                                            base_name: t.name.replace(/\s+/g, "")
                                        })
                                    })), "category" === a.sort) {
                                    var s = [{
                                        filter: "standing",
                                        title: "Standing"
                                    }, {
                                        filter: "seated",
                                        title: "Seated"
                                    }, {
                                        filter: "supine",
                                        title: "Supine"
                                    }, {
                                        filter: "prone",
                                        title: "Prone"
                                    }, {
                                        filter: "arm_leg_support",
                                        title: "Arm & Leg Support"
                                    }, {
                                        filter: "arm_balance_and_inversion",
                                        title: "Arm Balance & Inversion"
                                    }];
                                    s.forEach((function(t) {
                                        var a = e.filter((function(e) {
                                            return e.category === t.filter
                                        }));
                                        a.length > 0 && n.push({
                                            title: t.title,
                                            titleVisible: !0,
                                            poses: a
                                        })
                                    }))
                                }
                                if ("subcategory" === a.sort) {
                                    var i = [{
                                        filter: "backbend",
                                        title: "Backbend"
                                    }, {
                                        filter: "forward_bend",
                                        title: "Forward Bend"
                                    }, {
                                        filter: "lateral_bend",
                                        title: "Lateral Bend"
                                    }, {
                                        filter: "twist",
                                        title: "Twist"
                                    }, {
                                        filter: "balancing",
                                        title: "Balancing"
                                    }, {
                                        filter: "neutral",
                                        title: "Neutral"
                                    }];
                                    i.forEach((function(t) {
                                        var a = e.filter((function(e) {
                                            return e.subcategory === t.filter
                                        }));
                                        a.length > 0 && n.push({
                                            title: t.title,
                                            titleVisible: !0,
                                            poses: a
                                        })
                                    }))
                                }
                                if ("difficulty" === a.sort) {
                                    var r = [{
                                        filter: "beginner",
                                        title: "Beginner"
                                    }, {
                                        filter: "intermediate",
                                        title: "Intermediate"
                                    }, {
                                        filter: "expert",
                                        title: "Advanced"
                                    }];
                                    r.forEach((function(t) {
                                        var a = e.filter((function(e) {
                                            return e.difficulty === t.filter
                                        }));
                                        a.length > 0 && n.push({
                                            title: t.title,
                                            titleVisible: !0,
                                            poses: a
                                        })
                                    }))
                                }
                                "alphabetical" === a.sort && e.length && n.push({
                                    title: "Alphabetical",
                                    titleVisible: !1,
                                    poses: e
                                }), a.posesForDisplay = n, a.loading = !1
                            })).catch((function(t) {
                                a.loading = !1
                            }))
                        }
                    },
                    loadState: function() {
                        this.search = this.store.search, this.sort = this.store.sort
                    },
                    routeChanged: function(t, e) {
                        this.assignParamData(), this.fetchData(), this.setMeta()
                    },
                    setMeta: function() {
                        document.title = "Yoga Poses Dictionary | Pocket Yoga";
                        var t = document.querySelector('meta[name="description"]'),
                            e = document.querySelector('meta[name="keywords"]');
                        null !== t && t.setAttribute("content", "A searchable dictionary of yoga poses. Find a new yoga pose or learn about one of your favorites with images, descriptions, and benefits for each pose."), null !== e && e.setAttribute("content", "yoga poses, search, categories, difficulty")
                    },
                    updateUrl: function() {
                        var t = {};
                        this.sort && (t.sort = this.sort), null !== this.search && "" !== this.search.trimLeft() && (t.search = this.search.trimLeft()), this.$router.push({
                            query: t
                        })
                    }
                },
                filters: {
                    alphanumeric: function(t) {
                        return t ? t.replace(/\W/g, "") : ""
                    },
                    commaSpace: function(t) {
                        if (!t) return "";
                        var e = t.split(",");
                        switch (e.length) {
                            case 2:
                                return "".concat(e[0], ", ").concat(e[1]);
                            case 3:
                                return 0 === e[1].length ? "".concat(e[0], " (").concat(e[2], ")") : "".concat(e[0], ", ").concat(e[1], " (").concat(e[2], ")");
                            default:
                                return t
                        }
                    },
                    formatSanskrit: function(t) {
                        return t ? t[0].simplified : ""
                    },
                    thumbImg: function(t) {
                        if (!t) return "";
                        var e = "https://pocketyoga.com/assets/images/thumbnails146/".concat(t.base_name);
                        return null !== t.preferred_side && (t.two_sided || t.sideways) && (e += "_".concat(t.preferred_side.charAt(0).toUpperCase())), "".concat(e, "-tn146.png")
                    }
                }
            }),
            D = T,
            L = (n("baf9"), Object(r["a"])(D, p, f, !1, null, null, null)),
            E = L.exports,
            A = function() {
                var t = this,
                    e = t.$createElement,
                    n = t._self._c || e;
                return n("section", {
                    staticClass: "mainProduct",
                    style: {
                        height: t.conserveHeight
                    }
                }, [n("div", {
                    staticClass: "overlay",
                    class: {
                        enabled: null !== t.open
                    },
                    on: {
                        click: function(e) {
                            t.open = null
                        }
                    }
                }), t.notFound ? n("p", {
                    staticClass: "not-found"
                }, [t._v("Pose not found")]) : t._e(), t.loading || t.notFound ? t._e() : n("div", {
                    staticClass: "mainProductContainer"
                }, [t.pose.variations ? n("section", {
                    staticClass: "poseVariations"
                }, [t.pose.variations.length > 9 ? n("a", {
                    staticClass: "shiftLeft",
                    class: {
                        hidden: "0px" === t.initialLeft
                    },
                    attrs: {
                        href: "#"
                    },
                    on: {
                        click: t.shiftLeft
                    }
                }) : t._e(), n("div", {
                    staticClass: "variationsReel"
                }, [n("ul", {
                    style: {
                        left: t.initialLeft
                    },
                    attrs: {
                        id: "vars"
                    }
                }, t._l(t.pose.variation_objs, (function(e, a) {
                    return n("li", {
                        key: a,
                        class: {
                            selected: e.base_name === t.pose.base_name
                        }
                    }, [n("router-link", {
                        attrs: {
                            to: e.base_name,
                            title: e.display_name
                        }
                    }, [n("img", {
                        attrs: {
                            src: t._f("relatedMedImg")(e),
                            alt: ""
                        }
                    })])], 1)
                })), 0)]), t.pose.variations.length > 9 ? n("a", {
                    staticClass: "shiftRight",
                    class: {
                        hidden: "0px" !== t.initialLeft
                    },
                    attrs: {
                        href: "#"
                    },
                    on: {
                        click: t.shiftRight
                    }
                }) : t._e()]) : t._e(), n("section", {
                    staticClass: "poseHeading"
                }, [n("ul", [n("li", [n("h3", [t._v(t._s(t.pose.display_name))])]), t._l(t.pose.sanskrit_names, (function(e, a) {
                    return n("li", {
                        key: a
                    }, [n("a", {
                        staticClass: "big",
                        attrs: {
                            href: "#",
                            "data-index": a
                        },
                        on: {
                            click: t.openTranslation
                        }
                    }, [t._v("\n            " + t._s(e.simplified) + " (" + t._s(e.latin) + ") " + t._s(e.devanagari) + "\n          ")])])
                }))], 2), t._l(t.pose.sanskrit_names, (function(e, a) {
                    return n("div", {
                        key: a,
                        staticClass: "translations",
                        class: {
                            enabled: t.open === a
                        }
                    }, [n("h2", [t._v(t._s(e.simplified))]), n("h3", [t._v("(" + t._s(e.latin) + ")")]), n("h4", [t._v(t._s(e.devanagari))]), n("ul", t._l(e.translation, (function(e, a) {
                        return n("li", {
                            key: a
                        }, [t._v("\n              " + t._s(e.simplified) + "\n              (" + t._s(e.latin) + ")\n              " + t._s(e.devanagari) + " =\n              " + t._s(e.description) + "\n            ")])
                    })), 0)])
                }))], 2), n("section", {
                    staticClass: "poseDescription"
                }, [t.pose.sanskrit_interpretation ? n("ul", {
                    domProps: {
                        innerHTML: t._s(t.pose.sanskrit_interpretation)
                    }
                }) : t._e(), n("ul", [t.pose.aka ? n("li", [n("h5", {
                    staticClass: "category"
                }, [t._v("Alt. Name:")]), n("span", {
                    staticClass: "cat"
                }, [t._v(t._s(t.pose.aka.join(" / ")))])]) : t._e(), t.pose.category ? n("li", [n("h5", {
                    staticClass: "category"
                }, [t._v("Category:")]), n("span", {
                    staticClass: "cat"
                }, [t._v(t._s(t._f("formatCategory")(t.pose.category)) + " /\n            " + t._s(t._f("formatCategory")(t.pose.subcategory)) + "\n          ")])]) : t._e(), t.pose.difficulty ? n("li", [n("h5", {
                    staticClass: "category"
                }, [t._v("Difficulty:")]), n("span", {
                    staticClass: "cat"
                }, [t._v(t._s(t._f("capitalize")(t.pose.difficulty)))])]) : t._e()]), n("ul", [t.pose.description ? n("li", [n("h5", [t._v("Description")]), n("p", {
                    staticClass: "text",
                    domProps: {
                        innerHTML: t._s(t.nl2br(t.pose.description))
                    },
                    on: {
                        click: t.changePose
                    }
                })]) : t._e()]), n("ul", [t.pose.benefits ? n("li", [n("h5", [t._v("Benefits")]), n("p", {
                    staticClass: "text",
                    domProps: {
                        innerHTML: t._s(t.nl2br(t.pose.benefits))
                    },
                    on: {
                        click: t.changePose
                    }
                })]) : t._e()])]), n("section", {
                    staticClass: "poseImages"
                }, [n("div", {
                    staticClass: "poseImageMain",
                    class: {
                        rotated: t.rotate
                    }
                }, [n("img", {
                    attrs: {
                        src: t._f("mainImg")(t.pose),
                        alt: t.pose.alt
                    }
                }), n("img", {
                    attrs: {
                        src: t._f("mainImg")(t.pose, !0),
                        alt: t.pose.alt
                    }
                }), t.pose.two_sided || t.pose.sideways ? n("link", {
                    attrs: {
                        rel: "preload",
                        href: t._f("mainImg")(t.pose, !0),
                        as: "image"
                    }
                }) : t._e()]), n("div", {
                    staticClass: "poseActions"
                }, [t.pose.two_sided || t.pose.sideways ? n("button", {
                    attrs: {
                        type: "button",
                        id: "rotateButton"
                    },
                    on: {
                        click: t.changeSide
                    }
                }) : t._e()])]), n("section", {
                    staticClass: "poseImages relatedPoses"
                }, [t.pose.previous_poses.length ? n("div", {
                    staticClass: "related-poses previous-poses"
                }, [n("h2", [t._v("Transitioning to this Pose")]), n("ul", t._l(t.pose.previous_pose_objs, (function(e, a) {
                    return n("li", {
                        key: a
                    }, [n("router-link", {
                        attrs: {
                            to: e.base_name,
                            title: e.display_name
                        }
                    }, [n("img", {
                        attrs: {
                            src: t._f("relatedImg")(e),
                            alt: ""
                        }
                    })])], 1)
                })), 0)]) : t._e(), t.pose.next_poses.length ? n("div", {
                    staticClass: "related-poses next-poses"
                }, [n("h2", [t._v("Transitioning away from this Pose")]), n("ul", t._l(t.pose.next_pose_objs, (function(e, a) {
                    return n("li", {
                        key: a
                    }, [n("router-link", {
                        attrs: {
                            to: e.base_name,
                            title: e.display_name
                        }
                    }, [n("img", {
                        attrs: {
                            src: t._f("relatedImg")(e),
                            alt: ""
                        }
                    })])], 1)
                })), 0)]) : t._e()])])])
            },
            $ = [],
            F = (n("20d6"), {}),
            B = (n("0bdc").remove, a["a"].extend({
                name: "pose",
                data: function() {
                    return {
                        conserveHeight: "auto",
                        initialLeft: "0px",
                        initialLoad: !1,
                        loading: !0,
                        notFound: !1,
                        open: null,
                        pose: null,
                        posesData: [],
                        poses: F,
                        rotate: !1
                    }
                },
                mounted: function() {
                    this.fetchData()
                },
                watch: {
                    $route: "routeChanged"
                },
                methods: {
                    changePose: function(t) {
                        t.preventDefault();
                        var e = t.target;
                        "a" === e.localName && this.$router.push("".concat(e.getAttribute("href")))
                    },
                    changeSide: function() {
                        this.rotate = !this.rotate
                    },
                    fetchData: function() {
                        document.getElementsByClassName("mainProduct").length && (this.conserveHeight = "".concat(document.getElementsByClassName("mainProduct")[0].clientHeight, "px")), this.loading = !0, this.notFound = !1;
                        var t = this.$route.params.pose,
                            e = this.$route.params.pose.replace(/(?:^|_)(\w)/g, (function(t, e) {
                                return e.toUpperCase()
                            })).replace(/_/g, "");
                        if (t === e) {
                            var n = this;
                            fetch("/poses.json").then((function(t) {
                                if (!t.ok) throw t;
                                return t.json()
                            })).then((function(e) {
                                var a = e.find((function(e) {
                                    return t === e.name.replace(/\s+/g, "")
                                }));
                                if (!a) throw new Error("Not found");
                                a.base_name = a.name.replace(/\s+/g, "");
                                var s = [{
                                    source: "next_poses",
                                    result: "next_pose_objs"
                                }, {
                                    source: "previous_poses",
                                    result: "previous_pose_objs"
                                }, {
                                    source: "variations",
                                    result: "variation_objs"
                                }];
                                if (a.variations) a.variations.unshift(a.name);
                                else {
                                    var i = e.find((function(t) {
                                        return t.variations && t.variations.includes(a.name)
                                    }));
                                    i ? (a.variations = i.variations, a.variations.unshift(i.name)) : a.variations = [a.name]
                                }
                                return s.forEach((function(t) {
                                    a[t.result] = [], a[t.source] && (a[t.source] = a[t.source].map((function(t) {
                                        return t.replace(/\s+/g, "")
                                    })), a[t.result] = a[t.source].map((function(t) {
                                        return e.find((function(e) {
                                            return e.name.replace(/\s+/g, "") == t
                                        }))
                                    })).filter((function(t) {
                                        return void 0 !== t
                                    })).map((function(t) {
                                        return {
                                            name: t.name,
                                            base_name: t.name.replace(/\s+/g, ""),
                                            display_name: t.display_name,
                                            preferred_side: t.preferred_side,
                                            sideways: t.sideways,
                                            two_sided: t.two_sided
                                        }
                                    })))
                                })), n.posesData = e, a
                            })).then((function(t) {
                                var e = t;
                                if (e.sanskrit_interpretation) {
                                    e.sanskrit_interpretation = e.sanskrit_interpretation.replace(/\/\//g, "\\n\\n");
                                    var a = e.sanskrit_interpretation.split(/\\n/);
                                    e.sanskrit_interpretation = '<li><div class="trans">'.concat(a.join('</div></li><li><div class="trans">'), "</div></li>")
                                }
                                e.alt = "Yoga Pose: ".concat(e.display_name), "expert" === e.difficulty && (e.difficulty = "advanced");
                                var s = e.alt.match(/\bI{1,3}\b|\bIV\b|\bV\b/g);
                                if (s)
                                    for (var i = 0; i < s.length; i += 1) {
                                        var r = " 1",
                                            o = " One";
                                        switch (s[i]) {
                                            case "I":
                                                r = " 1", o = " One";
                                                break;
                                            case "II":
                                                r = " 2", o = " Two";
                                                break;
                                            case "III":
                                                r = " 3", o = " Three";
                                                break;
                                            case "IV":
                                                r = " 4", o = " Four";
                                                break;
                                            case "V":
                                                r = " 5", o = " Five";
                                                break;
                                            default:
                                                r = " 1", o = " One"
                                        }
                                        e.alt += ", ".concat(e.display_name.replace(" ".concat(s[i]), r), ", ").concat(e.display_name.replace(" ".concat(s[i]), o));
                                        break
                                    }
                                if (e.aka && (e.alt += ", ".concat(e.aka.join(", ")), e.alt = e.alt.trim()), e.sanskrit_names && (e.alt += ", ".concat(e.sanskrit_names.map((function(t) {
                                        return "".concat(t.latin, ", ").concat(t.simplified)
                                    })).join(", "))), !n.initialLoad && (n.initialLeft = "0px", e.variation_objs.length > 9))
                                    for (var c = 0; c < e.variation_objs.length; c += 1)
                                        if (e.variation_objs[c].base_name === e.base_name) {
                                            c > 8 && (n.initialLeft = "-".concat(100 * (e.variations.length - 9), "px"));
                                            break
                                        }
                                n.pose = e, n.setMeta(), n.rotate = !1, setTimeout((function() {
                                    n.initialLoad = !0, n.loading = !1, n.conserveHeight = "auto", setTimeout((function() {
                                        n.pose.variation_objs.findIndex((function(t) {
                                            return t.base_name === n.pose.base_name
                                        })) > 8 ? (document.getElementById("vars").style.left = "-".concat(100 * (n.pose.variation_objs.length - 9), "px"), n.initialLeft = "-".concat(100 * (n.pose.variation_objs.length - 9), "px")) : (document.getElementById("vars").style.left = "0px", n.initialLeft = "0px")
                                    }))
                                }))
                            })).catch((function() {
                                n.notFound = !0, n.rotate = !1, setTimeout((function() {
                                    n.loading = !1, n.conserveHeight = "auto"
                                }))
                            }))
                        } else window.location.href = e
                    },
                    nl2br: function(t) {
                        var e = this;
                        return t ? t.replace(/\\n/g, "<br/>").replace(/\\"/g, '"').replace(/\/\/(.+?)\/\//g, (function(t, n) {
                            return '<a href="'.concat(n.replace(/\s+/g, ""), '">').concat(e.posesData.find((function(t) {
                                return t.name === n
                            })).display_name, "</a>")
                        })) : ""
                    },
                    openTranslation: function(t) {
                        t.preventDefault(), t && t.target && (this.open = parseInt(t.target.getAttribute("data-index") || "0", 10))
                    },
                    routeChanged: function() {
                        this.fetchData()
                    },
                    setMeta: function() {
                        if (null !== this.pose) {
                            document.title = "Yoga Pose: ".concat(this.pose.display_name, " | Pocket Yoga");
                            var t = document.querySelector('meta[name="description"]'),
                                e = document.querySelector('meta[name="keywords"]');
                            if (null !== t && t.setAttribute("content", "A detailed description and benefits of the ".concat(this.pose.display_name, " pose including image, sanskrit name, category, difficulty, and a list of variations, previous, and next poses.")), null !== e && null !== this.pose) {
                                var n = "yoga pose, ".concat(this.pose.display_name);
                                this.pose.aka && (n += ", ".concat(this.pose.aka.join(", "))), this.pose.sanskrit_name && (n += ", ".concat(this.pose.sanskrit_name)), e.setAttribute("content", n)
                            }
                        }
                    },
                    shiftLeft: function(t) {
                        t.preventDefault(), document.getElementById("vars").style.left = "0px", this.initialLeft = "0px"
                    },
                    shiftRight: function(t) {
                        t.preventDefault(), document.getElementById("vars").style.left = "-".concat(100 * (this.pose.variations.length - 9), "px"), this.initialLeft = "-".concat(100 * (this.pose.variations.length - 9), "px")
                    }
                },
                filters: {
                    capitalize: function(t) {
                        return t ? "".concat(t.toString().charAt(0).toUpperCase()).concat(t.toString().slice(1)) : ""
                    },
                    formatCategory: function(t) {
                        if (!t) return "";
                        for (var e = t.replace(/_/g, " ").split(" "), n = 0; n < e.length; n += 1) e[n] = "".concat(e[n].charAt(0).toUpperCase()).concat(e[n].slice(1));
                        return e.join(" ")
                    },
                    mainImg: function(t, e) {
                        if (!t) return "";
                        var n = "https://pocketyoga.com/assets/images/full/".concat(t.base_name);
                        return null !== t.preferred_side && (t.two_sided || t.sideways) && (e && "left" === t.preferred_side ? n += "_R" : e && "right" === t.preferred_side ? n += "_L" : n += "_".concat(t.preferred_side.charAt(0).toUpperCase())), "".concat(n, ".png")
                    },
                    relatedMedImg: function(t) {
                        if (!t) return "";
                        var e = "https://pocketyoga.com/assets/images/thumbnails90/".concat(t.base_name);
                        return null !== t.preferred_side && (t.two_sided || t.sideways) && (e += "_".concat(t.preferred_side.charAt(0).toUpperCase())), "".concat(e, "-tn90.png")
                    },
                    relatedImg: function(t) {
                        if (!t) return "";
                        var e = "https://pocketyoga.com/assets/images/thumbnails75/".concat(t.base_name);
                        return null !== t.preferred_side && (t.two_sided || t.sideways) && (e += "_".concat(t.preferred_side.charAt(0).toUpperCase())), "".concat(e, "-tn75.png")
                    }
                }
            })),
            M = B,
            U = (n("883d"), Object(r["a"])(M, A, $, !1, null, null, null)),
            H = U.exports;
        a["a"].use(u["a"]);
        var N = new u["a"]({
            mode: "history",
            base: "/pose/",
            routes: [{
                path: "/",
                name: "library",
                component: E
            }, {
                path: "/:pose",
                name: "pose",
                component: H
            }]
        });
        a["a"].config.productionTip = !1, new a["a"]({
            router: N,
            render: function(t) {
                return t(l)
            }
        }).$mount("#app")
    },
    fc42: function(t, e, n) {
        "use strict";
        n("7997")
    }
});
//# sourceMappingURL=app.c388a31d.js.map